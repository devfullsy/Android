package com.kingkmotivation.kingkmotivation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Database;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.kingkmotivation.kingkmotivation.base.DataVideo;
import com.kingkmotivation.kingkmotivation.entities.Video;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private List<Video> videos;
    private Video video = new Video();
    private Context context;
    private RecyclerView recyVideo;
    @SuppressLint({"MissingInflatedId", "ResourceType"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview);
        recyVideo = findViewById(R.id.rvVideo);
        context = getApplicationContext();
        RecyclerView.LayoutManager layoutManager= new LinearLayoutManager(context);
        recyVideo.setHasFixedSize(true);
        recyVideo.setLayoutManager(layoutManager);
    }

     @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.ajoutvideo,menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.mnajoutvideo){
            Intent activite = new Intent(context, AddVideo.class);
            startActivity(activite);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

   @Override
    protected void onStart() {
        super.onStart();
        videos = DataVideo.getDb(context).videoRepository().list();
        VideoAdapter videoAdapter = new VideoAdapter(videos, new VideoAdapter.OnItemClickListener(){

            @Override
            public void onItemClick(Video video) {

                Intent activite = new Intent(context, InfosVideo.class);
                activite.putExtra("video",video);
                startActivity(activite);
            }
        } );
        recyVideo.setAdapter(videoAdapter);
    }
}