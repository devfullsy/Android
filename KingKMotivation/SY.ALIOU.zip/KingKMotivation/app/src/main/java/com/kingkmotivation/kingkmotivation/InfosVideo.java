package com.kingkmotivation.kingkmotivation;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.icu.text.IDNA;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.kingkmotivation.kingkmotivation.entities.Video;

public class InfosVideo extends AppCompatActivity {

    private  Video video;
    private TextView tvtitre,tvdescrp,tvcathegorie,tvurl;
    private String titre,url,description,cathegorie;

    private Button btnvoirvideo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infos_video);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        video = (Video) getIntent().getSerializableExtra("video");
        titre = video.getName();
        url = video.getUrl();
        description = video.getDescription();
        cathegorie = video.getCathegorie();

        btnvoirvideo = findViewById(R.id.btnVoirVideo);
        tvtitre = findViewById(R.id.tvTitre);
        tvdescrp = findViewById(R.id.tvDescriptionDT);
        tvcathegorie = findViewById(R.id.tvCathegorieDT);
        tvurl = findViewById(R.id.tvUrl);

        tvtitre.setText(titre);
        tvurl.setText(url);
        tvcathegorie.setText(cathegorie);
        tvdescrp.setText(description);

    btnvoirvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    InfosVideo.this.startActivity(intent);

                } catch (ActivityNotFoundException e){

                }
            }
        });
    }


    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}