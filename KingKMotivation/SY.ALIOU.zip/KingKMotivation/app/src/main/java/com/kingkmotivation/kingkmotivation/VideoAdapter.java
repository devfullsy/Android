package com.kingkmotivation.kingkmotivation;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kingkmotivation.kingkmotivation.entities.Video;

import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Video video);
    }
    private List<Video> videos;

    private  OnItemClickListener listener;

    public VideoAdapter(List<Video> videos, OnItemClickListener listener){
        this.videos = videos;
        this.listener = listener;
    }
    static class VideoViewHolder extends RecyclerView.ViewHolder{
        private TextView tvname , tvdescrip;
        public VideoViewHolder(View itemView){
            super(itemView);
            tvname = itemView.findViewById(R.id.tvnamerv);
            tvdescrip = itemView.findViewById(R.id.tvdescriprv);
        }

        public void bind(final Video video, final OnItemClickListener listener) {
            tvname.setText(video.getName());
            tvdescrip.setText(video.getDescription());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    listener.onItemClick(video);
                }
            });
    }
      }

    @Override
    public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_item,parent,false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(VideoViewHolder holder, int position) {
        holder.bind(videos.get(position),listener);
    }

    @Override
    public int getItemCount() {
        return videos.size();
    }
}
